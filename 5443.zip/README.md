simplycarousel
==============

Simply Carousel is a jQuery plugin for simple image slider
